#include <stddef.h>
#include <stdint.h>
#include <dlpack/dlpack.h>
const size_t class2_softmax_len = 4;
float class2_softmax[] ={3.493452993552637e-07, 7.14187444827985e-06, 0.9999911785125732, 1.3108854091115063e-06, };

