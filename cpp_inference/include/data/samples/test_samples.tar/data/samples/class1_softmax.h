#include <stddef.h>
#include <stdint.h>
#include <dlpack/dlpack.h>
const size_t class1_softmax_len = 4;
float class1_softmax[] ={6.342926184288444e-09, 1.0, 4.9859678885599834e-11, 1.3336123316776138e-09, };

