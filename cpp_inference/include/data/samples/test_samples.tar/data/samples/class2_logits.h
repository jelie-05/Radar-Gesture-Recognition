#include <stddef.h>
#include <stdint.h>
#include <dlpack/dlpack.h>
const size_t class2_logits_len = 4;
float class2_logits[] ={-5.753120422363281, -2.7354507446289062, 9.114075660705566, -4.430723190307617, };

