#include <stddef.h>
#include <stdint.h>
#include <dlpack/dlpack.h>
const size_t class0_logits_len = 4;
float class0_logits[] ={11.754775047302246, -6.071613788604736, -4.648063659667969, -4.3686723709106445, };

