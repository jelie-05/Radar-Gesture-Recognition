#include <stddef.h>
#include <stdint.h>
#include <dlpack/dlpack.h>
const size_t class3_softmax_len = 4;
float class3_softmax[] ={1.7008542352314748e-09, 5.891137334401719e-06, 1.075034674613562e-07, 0.9999939799308777, };

