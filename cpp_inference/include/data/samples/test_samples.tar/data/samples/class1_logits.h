#include <stddef.h>
#include <stdint.h>
#include <dlpack/dlpack.h>
const size_t class1_logits_len = 4;
float class1_logits[] ={-1.2850290536880493, 17.590896606445312, -6.130911827087402, -2.844477891921997, };

