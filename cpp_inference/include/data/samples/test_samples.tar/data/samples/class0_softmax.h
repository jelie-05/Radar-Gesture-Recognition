#include <stddef.h>
#include <stdint.h>
#include <dlpack/dlpack.h>
const size_t class0_softmax_len = 4;
float class0_softmax[] ={0.9999998211860657, 1.8117473743473056e-08, 7.522073275367802e-08, 9.94662343600794e-08, };

