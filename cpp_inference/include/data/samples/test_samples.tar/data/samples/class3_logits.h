#include <stddef.h>
#include <stdint.h>
#include <dlpack/dlpack.h>
const size_t class3_logits_len = 4;
float class3_logits[] ={-6.1537981033325195, 1.996275544166565, -2.0074057579040527, 14.038331031799316, };

